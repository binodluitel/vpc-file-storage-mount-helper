# stunnel overview


### Short description

     The stunnel program is designed to work as an SSL encryption
     wrapper between remote client and local (inetd-startable) or
     remote servers. The goal is to facilitate SSL encryption and
     authentication for non-SSL-aware programs.

     stunnel can be used to add  SSL  functionality  to  commonly
     used  inetd  daemons  like  POP-2,  POP-3  and  IMAP servers
     without any changes in the programs' code.

### Compile instructions

     See INSTALL file.

### License

     See COPYING file.

### Other files you should read

     Changelog      What I did
     TODO           What I'm going to do

### Reporting problems and other contacts

     See FAQ file.
